<?php
/**
 * Archivo temporal para debug del SKU 2505053
 * Subir a la raíz de WordPress y acceder vía navegador
 */

require_once 'wp-load.php';
global $wpdb;

header('Content-Type: text/plain; charset=utf-8');

// Buscar el producto por SKU
$product_id = $wpdb->get_var($wpdb->prepare("
    SELECT post_id FROM {$wpdb->postmeta}
    WHERE meta_key = '_alg_ean' AND meta_value = %s
    LIMIT 1
", '2505053'));

if (!$product_id) {
    die("No se encontró producto con SKU 2505053\n");
}

echo "========== DATOS DEL PRODUCTO ==========\n";
echo "Product ID: {$product_id}\n";
echo "Stock actual: " . get_post_meta($product_id, '_stock', true) . "\n";
echo "SKU (_sku): " . get_post_meta($product_id, '_sku', true) . "\n";
echo "Nombre: " . get_the_title($product_id) . "\n\n";

echo "========== PERÍODOS SIN STOCK (últimos 60 días) ==========\n";
$periods = $wpdb->get_results($wpdb->prepare("
    SELECT
        id,
        product_id,
        sku,
        start_date,
        end_date,
        days_out,
        DATEDIFF(IFNULL(end_date, NOW()), start_date) as dias_calculados,
        created_at
    FROM {$wpdb->prefix}fc_stockout_periods
    WHERE product_id = %d
        AND (end_date IS NULL OR end_date >= DATE_SUB(NOW(), INTERVAL 60 DAY))
    ORDER BY start_date DESC
", $product_id));

if ($periods) {
    foreach ($periods as $p) {
        echo "ID: {$p->id}\n";
        echo "  Inicio: {$p->start_date}\n";
        echo "  Fin: " . ($p->end_date ?: 'AÚN SIN STOCK') . "\n";
        echo "  Días registrados: {$p->days_out}\n";
        echo "  Días calculados: {$p->dias_calculados}\n";
        echo "  Created: {$p->created_at}\n\n";
    }
} else {
    echo "No hay períodos sin stock registrados\n\n";
}

echo "========== CÁLCULO CON LA FUNCIÓN ACTUAL ==========\n";
$fecha_inicio = date('Y-m-d', strtotime("-60 days"));
echo "Fecha inicio análisis: {$fecha_inicio}\n";

$dias_sin_stock = $wpdb->get_var($wpdb->prepare("
    SELECT SUM(
        CASE
            WHEN start_date < %s THEN
                DATEDIFF(IFNULL(end_date, NOW()), %s)
            ELSE
                DATEDIFF(IFNULL(end_date, NOW()), start_date)
        END
    ) as total_dias
    FROM {$wpdb->prefix}fc_stockout_periods
    WHERE product_id = %d
    AND (end_date IS NULL OR end_date >= %s)
    AND start_date <= NOW()
", $fecha_inicio, $fecha_inicio, $product_id, $fecha_inicio));

echo "Días sin stock calculados por función: " . ($dias_sin_stock ?: 0) . "\n\n";

echo "========== TODOS LOS PERÍODOS (sin filtro de fecha) ==========\n";
$all_periods = $wpdb->get_results($wpdb->prepare("
    SELECT
        id,
        start_date,
        end_date,
        days_out,
        DATEDIFF(IFNULL(end_date, NOW()), start_date) as dias_reales
    FROM {$wpdb->prefix}fc_stockout_periods
    WHERE product_id = %d
    ORDER BY start_date DESC
", $product_id));

if ($all_periods) {
    foreach ($all_periods as $p) {
        echo "ID {$p->id}: {$p->start_date} → " . ($p->end_date ?: 'ABIERTO') .
             " (guardado: {$p->days_out} días, real: {$p->dias_reales} días)\n";
    }
} else {
    echo "No hay períodos registrados\n";
}

echo "\n========== VENTAS ÚLTIMOS 60 DÍAS ==========\n";
$sales = $wpdb->get_results($wpdb->prepare("
    SELECT
        DATE(p.post_date) as fecha,
        SUM(oim.meta_value) as cantidad
    FROM {$wpdb->prefix}woocommerce_order_items oi
    INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim ON oi.order_item_id = oim.order_item_id
    INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim2 ON oi.order_item_id = oim2.order_item_id
    INNER JOIN {$wpdb->posts} p ON oi.order_id = p.ID
    WHERE p.post_type = 'shop_order'
        AND p.post_status IN ('wc-completed', 'wc-processing', 'wc-shipped')
        AND p.post_date >= DATE_SUB(NOW(), INTERVAL 60 DAY)
        AND oim.meta_key = '_qty'
        AND (
            (oim2.meta_key = '_product_id' AND oim2.meta_value = %d)
            OR (oim2.meta_key = '_variation_id' AND oim2.meta_value = %d)
        )
    GROUP BY DATE(p.post_date)
    ORDER BY p.post_date
", $product_id, $product_id));

if ($sales) {
    $total = 0;
    foreach ($sales as $s) {
        echo "  {$s->fecha}: {$s->cantidad} unidades\n";
        $total += $s->cantidad;
    }
    echo "\nTotal vendido en 60 días: {$total} unidades\n";
    echo "Promedio sin ajuste: " . round($total / 60, 2) . " unidades/día\n";

    if ($dias_sin_stock > 0) {
        $dias_con_stock = 60 - $dias_sin_stock;
        echo "Días con stock: {$dias_con_stock}\n";
        if ($dias_con_stock > 0) {
            echo "Promedio ajustado: " . round($total / $dias_con_stock, 2) . " unidades/día\n";
        }
    }
} else {
    echo "No hay ventas registradas\n";
}

echo "\n========== DEBUG: Query paso a paso ==========\n";
echo "1. ¿Qué períodos encuentra la query?\n";
$debug = $wpdb->get_results($wpdb->prepare("
    SELECT
        id,
        start_date,
        end_date,
        start_date < %s as 'empezo_antes',
        DATEDIFF(IFNULL(end_date, NOW()), %s) as 'dias_si_empezo_antes',
        DATEDIFF(IFNULL(end_date, NOW()), start_date) as 'dias_si_empezo_despues'
    FROM {$wpdb->prefix}fc_stockout_periods
    WHERE product_id = %d
    AND (end_date IS NULL OR end_date >= %s)
    AND start_date <= NOW()
", $fecha_inicio, $fecha_inicio, $product_id, $fecha_inicio));

foreach ($debug as $d) {
    echo "\nPeriodo ID {$d->id}:\n";
    echo "  Start: {$d->start_date}, End: " . ($d->end_date ?: 'NULL') . "\n";
    echo "  Empezó antes del rango? " . ($d->empezo_antes ? 'SÍ' : 'NO') . "\n";
    echo "  Días calculados: " . ($d->empezo_antes ? $d->dias_si_empezo_antes : $d->dias_si_empezo_despues) . "\n";
}
