jQuery(document).ready(function($) {
    // Por ahora está vacío, lo usaremos más adelante
    console.log('Forecast Compras cargado');
});