<?php
/**
 * Script para cerrar período sin stock incorrecto del SKU 2505053
 * Subir a la raíz de WordPress y ejecutar UNA SOLA VEZ
 */

require_once 'wp-load.php';
global $wpdb;

header('Content-Type: text/plain; charset=utf-8');

$product_id = 59640;
$period_id = 86;

// Verificar stock actual
$stock = get_post_meta($product_id, '_stock', true);
echo "Stock actual del producto: {$stock}\n\n";

if ($stock > 0) {
    echo "El producto TIENE stock, cerrando período incorrectamente abierto...\n\n";

    // Buscar la primera venta después de que se abrió el período
    $primera_venta = $wpdb->get_row($wpdb->prepare("
        SELECT DATE(p.post_date) as fecha_venta
        FROM {$wpdb->prefix}woocommerce_order_items oi
        INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim ON oi.order_item_id = oim.order_item_id
        INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim2 ON oi.order_item_id = oim2.order_item_id
        INNER JOIN {$wpdb->posts} p ON oi.order_id = p.ID
        WHERE p.post_type = 'shop_order'
            AND p.post_status IN ('wc-completed', 'wc-processing', 'wc-shipped')
            AND p.post_date >= '2025-07-29 21:16:56'
            AND oim.meta_key = '_qty'
            AND (
                (oim2.meta_key = '_product_id' AND oim2.meta_value = %d)
                OR (oim2.meta_key = '_variation_id' AND oim2.meta_value = %d)
            )
        ORDER BY p.post_date ASC
        LIMIT 1
    ", $product_id, $product_id));

    if ($primera_venta) {
        echo "Primera venta después del período: {$primera_venta->fecha_venta}\n";
        echo "Esto indica que el stock se repuso antes de esa fecha.\n\n";

        // Cerrar el período en la fecha de la primera venta
        $result = $wpdb->update(
            $wpdb->prefix . 'fc_stockout_periods',
            array(
                'end_date' => $primera_venta->fecha_venta,
                'days_out' => $wpdb->prepare("DATEDIFF(%s, start_date)", $primera_venta->fecha_venta)
            ),
            array('id' => $period_id),
            array('%s', '%s'),
            array('%d')
        );

        if ($result !== false) {
            echo "✅ Período cerrado exitosamente!\n\n";

            // Verificar el resultado
            $updated = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}fc_stockout_periods WHERE id = %d",
                $period_id
            ));

            echo "Período actualizado:\n";
            echo "  Inicio: {$updated->start_date}\n";
            echo "  Fin: {$updated->end_date}\n";
            echo "  Días sin stock: {$updated->days_out}\n";
        } else {
            echo "❌ Error al actualizar: " . $wpdb->last_error . "\n";
        }
    } else {
        echo "⚠️ No se encontraron ventas después del período.\n";
        echo "Probablemente el período se abrió por error.\n";
        echo "Cerrando con la fecha de apertura...\n\n";

        $result = $wpdb->update(
            $wpdb->prefix . 'fc_stockout_periods',
            array(
                'end_date' => '2025-07-29 21:16:56',
                'days_out' => 0
            ),
            array('id' => $period_id),
            array('%s', '%d'),
            array('%d')
        );

        if ($result !== false) {
            echo "✅ Período cerrado (0 días sin stock)\n";
        }
    }
} else {
    echo "⚠️ El producto realmente está sin stock. No se hace nada.\n";
}

echo "\n========== RECALCULAR PROYECCIÓN ==========\n";
echo "Ahora ejecuta desde el admin de WordPress:\n";
echo "Configuración → Actualizar Métricas\n";
echo "O espera a que el cron diario lo haga automáticamente.\n";
